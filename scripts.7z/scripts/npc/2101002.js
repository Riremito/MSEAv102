/* 	Eleska
	Ariant	
*/


function start() {
    cm.sendOk("Stay away from me, if you don't want any danger.");
}

function action() {
    cm.dispose()
}