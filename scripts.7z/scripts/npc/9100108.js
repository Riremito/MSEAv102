/*
	Dunno what Gachapon o.o'
 */

function action(mode, type, selection) {
    cm.dispose();
}