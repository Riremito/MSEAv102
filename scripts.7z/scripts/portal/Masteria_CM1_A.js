function enter(pi) {
    if (pi.itemQuantity(3992039) > 0) {
	pi.playPortalSE();
	pi.warp(610020000, "CM1_B");
    }
}