function enter(pi) {
    pi.playPortalSE();
    pi.warp(104000004, 1);
}