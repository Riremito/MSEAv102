function enter(pi) {
    pi.playPortalSE();
    pi.warp(230040420, "out00");
    return true;
}