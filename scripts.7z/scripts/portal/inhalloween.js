function enter(pi) {
    pi.playPortalSE();
    pi.warp(229000000, 0);
    return true;
}