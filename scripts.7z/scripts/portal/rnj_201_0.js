function enter(pi) {
    if (pi.getMap().getReactorByName("rnj31_out").getState() > 0) {
	pi.warp(926100200,0);
    } else {
	pi.playerMessage(5, "The portal is not open.");
    }
}