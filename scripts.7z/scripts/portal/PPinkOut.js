function enter(pi) {
    pi.playPortalSE();
    pi.warp(270050000, 0);
	return true;
}