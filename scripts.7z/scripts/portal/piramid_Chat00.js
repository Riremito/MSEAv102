function enter(pi) {
    pi.showWZEffect("Effect/Direction2.img/piramid/anubis");
	return true;
}