function enter(pi) {
    pi.summonMsg("Just a little bit more, and you'll reach the town. I'll head over there first, since I also have some things to take care of. There's no need to rush, Aran. I'll see you there.")
}