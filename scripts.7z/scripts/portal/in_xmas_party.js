function enter(pi) {
    pi.openNpc(9209100);
}