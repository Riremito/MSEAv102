function enter(pi) {
    pi.playPortalSE();
    pi.warp(702200001, 0);
}