function enter(pi) {
    pi.warp(910050300,0);
}