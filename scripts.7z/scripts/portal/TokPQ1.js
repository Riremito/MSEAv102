function enter(pi) {
    pi.warp(802000802, 0);
    return true;
}