function enter(pi) {
    pi.playPortalSE();
    pi.warp(pi.getPlayer().getMapId() - 10,"left01");
}