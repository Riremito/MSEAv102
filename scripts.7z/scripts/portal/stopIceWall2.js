function enter(pi) {
    //nothing
}