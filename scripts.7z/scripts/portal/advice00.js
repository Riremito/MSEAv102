function enter(pi) {
    pi.showInstruction("Press #e#b[Left] or [Right] arrow key#k#n to move.", 250, 5);
}