function enter(pi) {
    pi.playPortalSE();
    pi.warp(802000310, 2);
    return true;
}