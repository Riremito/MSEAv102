function enter(pi) {
	//2022698
	pi.openNpc(2022005);
}