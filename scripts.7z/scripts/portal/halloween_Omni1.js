function enter(pi) {
    pi.playerMessage("It seems to be locked.");
}