function enter(pi) {
    if (!pi.haveItem(4031448)) {
	pi.gainItem(4031448, 1);
    }
    pi.warp(220070400, 0);
    return true;
}