/*
 * Ellinia
 * Enter Magician magic library
 * TODO : mapid 910110000 for cygnus quest
 */
function enter(pi) {
    pi.playPortalSE();
    pi.warp(101000003, 8);
}