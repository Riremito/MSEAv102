function enter(pi) {
	pi.warp(610030800, 0);
	pi.gainNX(4000);
}