function enter(pi) {
	pi.playPortalSE();
    pi.warp(100030200, "east00");
    return true;
}  