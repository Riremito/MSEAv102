function enter(pi) {
	pi.warp(980010000, "sp");
	return true;
}