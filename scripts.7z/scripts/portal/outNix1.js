function enter(pi) {
	pi.warp(240020101,0);
}