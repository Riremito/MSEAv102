function enter(pi) {
	pi.playPortalSE();
	pi.warp(900090100);
	return true;
}