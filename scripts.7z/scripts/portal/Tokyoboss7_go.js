function enter(pi) {
    pi.playPortalSE();
    pi.warp(802000820, 0);
    return true;
}