function enter(pi) {
    pi.playPortalSE();
    pi.warp(240020401, "out00");
}