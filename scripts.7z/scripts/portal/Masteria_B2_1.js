function enter(pi) {
    if (pi.itemQuantity(3992040) > 0) {
	pi.playPortalSE();
	pi.warp(610010005, "sU6_1");
    }
}