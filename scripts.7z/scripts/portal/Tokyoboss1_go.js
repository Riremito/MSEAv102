function enter(pi) {
    pi.playPortalSE();
    pi.warp(802000210, 3);
    return true;
}