function enter(pi) {
}