function enter(pi) {
    if (!pi.dojoAgent_NextMap(false, false)) {
	pi.playerMessage("There are still some monsters remaining.");
    }
}