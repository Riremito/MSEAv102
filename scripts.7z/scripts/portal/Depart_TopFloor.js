function enter(pi) {
    pi.playPortalSE();
    pi.warp(103040440,0);
}