function enter(pi) {
    pi.playPortalSE();
    pi.warp(610020015, "CC6_A");
}