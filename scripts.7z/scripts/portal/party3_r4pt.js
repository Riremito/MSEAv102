function enter(pi) {
   
//i don't really care
	pi.warpS(pi.getMapId(), "in01");
}