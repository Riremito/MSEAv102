function enter(pi) {
    pi.playPortalSE();
    pi.warp(802000710, 0);
    return true;
}