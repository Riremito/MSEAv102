function enter(pi) {
    pi.cancelItem(2210016);
    pi.playPortalSE();
    pi.warp(240000110, 0);
    return true;
}