function enter(pi) {
    if (pi.getPlayer().getEventInstance() != null) {
    	pi.gainExpR(100000);
    	pi.gainNX(2500);
    }
    pi.warp(921120001,0);
}