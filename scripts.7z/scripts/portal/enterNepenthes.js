function enter(pi) {
    if (pi.isQuestActive(21738)) {
	pi.warp(920030000,0);
    } else {
	pi.warp(200060001,0);
    }
}