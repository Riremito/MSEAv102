function enter(pi) {
	pi.warp(103000100,0);
	return true;
}