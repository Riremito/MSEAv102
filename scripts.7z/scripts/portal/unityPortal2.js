function enter(pi) {
	pi.openNpc(9010022);
	return true;
}