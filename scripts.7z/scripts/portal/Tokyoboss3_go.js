function enter(pi) {
    pi.playPortalSE();
    pi.warp(802000410, 1);
    return true;
}