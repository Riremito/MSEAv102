function enter(pi) {
    pi.openNpc(2111024);
    return false;
}