function enter(pi) {
	pi.playPortalSE();
	pi.warp(100030300);
	return true;
}