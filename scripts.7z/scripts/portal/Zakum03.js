/*
    Zakum Entrance
*/

function enter(pi) {
    pi.playerMessage(5, "Please talk to the NPC instead.");
    return true;
}