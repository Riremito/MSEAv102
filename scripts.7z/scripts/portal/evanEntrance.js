function enter(pi) {
	pi.warp(100030400, "east00");
	return true;
}